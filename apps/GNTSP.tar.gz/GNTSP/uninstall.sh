#!/bin/bash

echo "Deleting files..."
rm -rf ~/.local/GNTSP
rm -f ~/.ClayPotFrog/GNTSP.db
rm -f ~/Desktop/Greek_New_Testament_Study_Project.desktop

echo
echo "The application has been removed."
echo
read -p "Would you like to delete the Greek fonts that were installed with the program? (y/n) " -n 1
if [[ $REPLY =~ ^[Yy]$ ]]; then
	echo
	echo "Deleting fonts..."
	rm -f ~/.fonts/GalSILR.ttf
	rm -f ~/.fonts/GentiumAlt-R.ttf
	rm -f ~/.fonts/SBL_grk.ttf
	fc-cache -f ~/.fonts
fi

echo 
echo "Done!"
exit 0

