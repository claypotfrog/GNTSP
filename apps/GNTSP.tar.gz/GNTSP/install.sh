#!/bin/bash

if [[ $(id -u) -eq 0 ]]; then
	echo "Please run this script as your local user, not as root.  The program is meant to be installed locally for your user only."
	exit 1
fi

echo Copying the program files...
if [ ! -d "$HOME/.local/GNTSP" ]; then
#-p will create the parent as well if necessary
	mkdir -p ~/.local/GNTSP
fi
cp -a ./* ~/.local/GNTSP
cp ./Greek_New_Testament_Study_Project.desktop ~/Desktop/
sed -i "s|HOME|${HOME}|" ~/Desktop/Greek_New_Testament_Study_Project.desktop

echo
echo Installing Greek fonts...
if [ ! -d "$HOME/.fonts" ]; then
	mkdir ~/.fonts
fi
cp -a ./fonts/* ~/.fonts/
fc-cache -f ~/.fonts

echo
echo "Done!"
exit 0

